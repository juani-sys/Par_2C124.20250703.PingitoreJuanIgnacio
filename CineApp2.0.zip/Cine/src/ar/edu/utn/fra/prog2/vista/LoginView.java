/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.prog2.vista;

import ar.edu.utn.fra.prog2.controlador.LoginController;
import ar.edu.utn.fra.prog2.modelo.Cine;
import ar.edu.utn.fra.prog2.modelo.Cliente;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author juani
 */
public class LoginView {
    private Stage stage;
    private Cine cine;
    private LoginController controller;
    
    public LoginView(Stage stage, Cine cine){
        this.stage = stage;
        this.cine = cine;
        this.controller = new LoginController(cine);
    }
    
    public void mostrar(){
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        
        Label titulo = new Label("Bienvenido al cine");
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Contraseña");
        
        TextField nombreField = new TextField();
        nombreField.setPromptText("Nombre (solo para registrarse)");
        
       Button loginBtn = new Button("Iniciar Sesion");
       Button registrarBtn = new Button("Registrarse");
       Label mensaje = new Label();
       
       loginBtn.setOnAction(e->{
          String email = emailField.getText();
          String pass = passwordField.getText();
          Cliente c = controller.login(email, pass);
          if(c != null){
              mensaje.setText("Entrada exitosa. Bienvenido " + c.getNombre());
              new SalaView(stage, cine, c).mostrar();
          }else{
              mensaje.setText("Datos Invalidos");
          }
       });
       
       registrarBtn.setOnAction(e->{
           String nombre = nombreField.getText();
           String email = emailField.getText();
           String pass = passwordField.getText();
           boolean registrado = controller.registrar(nombre, email, pass);
           mensaje.setText(registrado ? "Registrado con exito." : "El cliente ya existe.");
       });
       
       root.getChildren().addAll(titulo, nombreField, emailField, passwordField, loginBtn, registrarBtn, mensaje);
       stage.setTitle("Entrar - Cine");
       stage.setScene(new Scene(root, 300, 300));
       stage.show();
    }
}
