/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.prog2.app;

import ar.edu.utn.fra.prog2.modelo.Cine;
import ar.edu.utn.fra.prog2.modelo.Sala;
import ar.edu.utn.fra.prog2.persistencia.PersistenciaDatos;
import ar.edu.utn.fra.prog2.vista.LoginView;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 *
 * @author lauca
 */

public class MainApp extends Application {
    private Cine cine;

    @Override
    public void init() {
        try {
            cine = PersistenciaDatos.cargarEstado();
        } catch (Exception e) {
            System.err.println("️ Error al cargar estado: " + e.getMessage());
            cine = new Cine();
        }

        if (cine.getSalas().isEmpty()) {
            cine.agregarSala(new Sala(1, "Dune: Parte 2", 5, 6));
            cine.agregarSala(new Sala(2, "Intensamente 2", 6, 7));
            cine.agregarSala(new Sala(3, "Deadpool & Wolverine", 4, 5));
        }
    }

    @Override
    public void start(Stage primaryStage) {
        LoginView loginView = new LoginView(primaryStage, cine);
        loginView.mostrar();
    }

    @Override
    public void stop() {
        try {
            PersistenciaDatos.guardarEstado(cine);
        } catch (Exception e) {
            System.err.println(" Error al guardar estado: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
